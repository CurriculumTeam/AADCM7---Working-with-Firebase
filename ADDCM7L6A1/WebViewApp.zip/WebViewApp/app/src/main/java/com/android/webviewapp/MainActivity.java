package com.android.webviewapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebView;

// This MainActivity class is created automatically when you are creating your project
public class MainActivity extends AppCompatActivity {

    WebView webView;  // declare webView

    @Override
    // this is the main method under which we write our code.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);  // call webView by their id from xml

        // this loadURl method helps to load the web page inside your app.
        webView.loadUrl("https://www.codingal.com/");  // here link for condigal is given so it will open codingal website.
    }
}