package com.android.navigationbarapp;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;

import android.os.Bundle;

// This MainActivity class is created automatically when you created your project.
public class MainActivity extends AppCompatActivity {
    public DrawerLayout drawerLayout;   // declare drawerLayout
    public ActionBarDrawerToggle actionBarDrawerToggle;  // declare actionBarDrawerToggle
    Toolbar toolbar;  // declare toolbar

    @Override
    // this is the main method under which we write our entire code of an app.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // getting drawerLayout and toolbar from xml by findViewById.
        drawerLayout = findViewById(R.id.drawerLayout);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);  

        // drawer layout instance to toggle the menu icon to open
        //drawer and back button to close drawer
        actionBarDrawerToggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.nav_open, R.string.nav_close);

        // Pass the open and close toggle for the drawer layout listener
        // to toggle the button
        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
    }
}