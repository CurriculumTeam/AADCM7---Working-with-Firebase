package com.android.googlemapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

// This MainActivity class is automatically created when you created your project.
public class MainActivity extends AppCompatActivity {
    Button launchMap;  // declare button

    @Override
    // this is the main method under which we write our entire code.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // get view by its id.
        launchMap = findViewById(R.id.launch);

        // add onclick listener so that when you click button map will launch
        launchMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // use intent to open google map.
                Intent intent = new Intent(Intent.ACTION_VIEW);
                // give geographical location longitude
                intent.setData(Uri.parse("geo:47.4925,19.0513"));
                Intent chooser = Intent.createChooser(intent,"Launch Maps");
                startActivity(chooser);   // start the activity.
            }
        });
    }
}