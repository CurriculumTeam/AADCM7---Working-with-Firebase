package com.android.imagestroingapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

// This mainActivity class is created automatically when you create a project.
public class MainActivity extends AppCompatActivity {
    ImageView image;  // view for image view
    Button selectImage,uploadImage;  // button view for selecting and uploading image.
    StorageReference reference;   // instance for firebase storage and StorageReference
    Uri imageUri; // Uri indicates, where the image will be picked from

    @Override
    // this is the main method under which we entire our entire code.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // calling views by their id.
        image = findViewById(R.id.image);
        selectImage = findViewById(R.id.selectImage);
        uploadImage = findViewById(R.id.uploadImage);

        // get the Firebase  storage reference
        reference = FirebaseStorage.getInstance().getReference().child("images");
        // adding on click listener on selectImage button.
        selectImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Defining Implicit Intent to mobile gallery
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent,123);
            }
        });
        // adding setOnclickListener on uploadImage
        uploadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                StorageReference storageReference = reference.child(String.valueOf(System.currentTimeMillis()));
                // adding listeners on upload
                // or failure of image
                storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                        if(task.isSuccessful()){ // if image is uploaded then it will show message.
                            Toast.makeText(MainActivity.this, "Successfully uploaded", Toast.LENGTH_SHORT).show();
                            image.setImageResource(R.drawable.ic_baseline_image_24);  //for default image.
                        }

                    }
                });

            }
        });
    }
// this method will take requestCode, resultCode and data as parameter.
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // checking request code and result code
        // if request code is PICK_IMAGE_REQUEST and
        // resultCode is RESULT_OK
        // then set image in the image view
        if (resultCode == RESULT_OK && requestCode == 123 && data!=null) {
                imageUri = data.getData();
                image.setImageURI(imageUri);
        }
    }
}